"""Day1 Agent 平台 —— 对象列表 + 详情 + 多 Agent 触发（统一 SSE）

启动：
    cp .env.example .env   # 填入 DEEPSEEK_API_KEY
    # 编辑 dify_agents.json 填入 Dify base_url 与 app-key
    pip install -r requirements.txt
    python app.py          # → http://localhost:8081

三条 Agent 通道（统一 SSE 协议：data: {"content": ...} ... data: [DONE]）：
    POST /gateway/chat        DeepSeek 直连（最原始的 LLM 调用）
    POST /gateway/dify/chat   Dify Agent 转发（低代码平台集成）
    POST /agent/single        LangChain ReAct（代码级 Agent + 工具调用）
"""
import json
import os
import sys
from pathlib import Path
from typing import Any, Iterator

sys.path.insert(0, str(Path(__file__).parent))

from dotenv import load_dotenv

load_dotenv()

import requests
from flask import Flask, Response, jsonify, render_template, request

app = Flask(__name__)


@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response

BASE_DIR = Path(__file__).parent
OBJECTS_FILE = BASE_DIR / "data" / "objects.json"
DIFY_CONFIG_FILE = BASE_DIR / "dify_agents.json"

with open(OBJECTS_FILE, encoding="utf-8") as f:
    OBJECTS: list[dict[str, Any]] = json.load(f)


# ── 页面 ─────────────────────────────────────────────


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/object/<object_id>")
def object_page(object_id: str):
    return render_template("detail.html", object_id=object_id)


# ── 对象 API（换场景 = 换 data/objects.json，接口不变）──


@app.route("/api/objects")
def api_objects():
    """对象列表 — 支持状态筛选 + 关键字搜索"""
    status = request.args.get("status", "")
    search = request.args.get("search", "").lower()

    result = OBJECTS
    if status:
        result = [o for o in result if o["status"] == status]
    if search:
        result = [
            o for o in result
            if search in o["id"].lower()
            or search in o["name"].lower()
            or search in o.get("category", "").lower()
        ]
    return jsonify({"total": len(result), "objects": result})


@app.route("/api/objects/<object_id>")
def api_object(object_id: str):
    """单对象详情"""
    for o in OBJECTS:
        if o["id"] == object_id:
            return jsonify({"found": True, "object": o})
    return jsonify({"found": False, "error": f"对象 {object_id} 不存在"}), 404


# ── SSE 工具函数 ─────────────────────────────────────


def sse(payload: dict[str, Any]) -> str:
    """统一 SSE 帧：data: {...}\n\n"""
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


SSE_DONE = "data: [DONE]\n\n"


def sse_response(generate: Iterator[str]) -> Response:
    return Response(generate, mimetype="text/event-stream",
                    headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"})


def _object_context(object_id: str) -> str:
    """把对象数据拼进 Prompt（DeepSeek/Dify 通道用：平台喂数据给 Agent）"""
    for o in OBJECTS:
        if o["id"] == object_id:
            return "对象数据：" + json.dumps(o, ensure_ascii=False)
    return ""


# ── 通道① DeepSeek 直连（原始 OpenAI 兼容 API + 流式）──


@app.route("/gateway/chat", methods=["POST"])
def gateway_chat():
    data = request.get_json() or {}
    question = data.get("question", "你是运维助手，请自我介绍")
    object_id = data.get("object_id", "")

    api_key = os.getenv("DEEPSEEK_API_KEY", "")
    base_url = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1").rstrip("/")
    model = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")

    print(f"\n{'='*60}")
    print(f"🌐 [DeepSeek] 直连请求: {question[:80]}...")
    print(f"{'='*60}")

    messages = [{"role": "system", "content": "你是运维分析助手，回答简洁，给出结论和建议。"}]
    ctx = _object_context(object_id)
    if ctx:
        messages.append({"role": "user", "content": ctx})
    messages.append({"role": "user", "content": question})

    def generate():
        if not api_key:
            yield sse({"error": "未配置 DEEPSEEK_API_KEY，请编辑 .env"})
            yield SSE_DONE
            return
        try:
            # 原始 HTTP 调用：POST /chat/completions + stream=true，逐行解析 SSE
            resp = requests.post(
                f"{base_url}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"model": model, "messages": messages, "stream": True},
                stream=True, timeout=120,
            )
            resp.raise_for_status()
            for raw in resp.iter_lines():
                line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                if not line or not line.startswith("data:"):
                    continue
                chunk = line[len("data:"):].strip()
                if chunk == "[DONE]":
                    break
                delta = json.loads(chunk)["choices"][0]["delta"]
                content = delta.get("content") or ""
                if content:
                    yield sse({"content": content})
        except Exception as e:
            print(f"  ❌ [DeepSeek] 错误: {e}")
            yield sse({"error": f"DeepSeek 调用失败: {e}"})
        print(f"  ✅ [DeepSeek] 完成\n")
        yield SSE_DONE

    return sse_response(generate())


# ── 通道② Dify Agent 转发（streaming 逐 chunk 转发）────


def _load_dify_config() -> dict[str, Any]:
    """每次实时读，改配置无需重启"""
    try:
        return json.loads(DIFY_CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"base_url": "", "agents": []}


@app.route("/gateway/dify/agents")
def gateway_dify_agents():
    """Dify Agent 列表（不泄露 api_key）"""
    cfg = _load_dify_config()
    agents = [
        {"id": a.get("id"), "name": a.get("name"), "configured": bool(a.get("api_key"))}
        for a in cfg.get("agents", [])
    ]
    return jsonify({"base_url": cfg.get("base_url", ""), "agents": agents})


@app.route("/gateway/dify/chat", methods=["POST"])
def gateway_dify_chat():
    data = request.get_json() or {}
    question = data.get("question", "你好，请自我介绍")
    object_id = data.get("object_id", "")
    agent_id = data.get("agent_id")

    cfg = _load_dify_config()
    agents = cfg.get("agents", [])
    agent = next((a for a in agents if a.get("id") == agent_id), None) or (agents[0] if agents else None)
    base_url = cfg.get("base_url", "").rstrip("/")

    ctx = _object_context(object_id)
    query = f"{ctx}\n\n{question}" if ctx else question

    print(f"\n{'='*60}")
    print(f"🦊 [Dify] 请求: agent={agent.get('name', '?') if agent else '?'} q={question[:60]}...")
    print(f"{'='*60}")

    def generate():
        if not agent or not agent.get("api_key"):
            yield sse({"error": "未配置 Dify Agent，请编辑 dify_agents.json 填入 base_url 与 api_key"})
            yield SSE_DONE
            return
        try:
            resp = requests.post(
                f"{base_url}/chat-messages",
                headers={"Authorization": f"Bearer {agent['api_key']}", "Content-Type": "application/json"},
                json={"inputs": {}, "query": query, "response_mode": "streaming", "user": "day1-platform"},
                stream=True, timeout=120,
            )
            resp.raise_for_status()
            for raw in resp.iter_lines():
                line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                if not line or not line.startswith("data:"):
                    continue
                event = json.loads(line[len("data:"):].strip())
                # Dify 流式事件：message 是回答增量，其余（agent_thought 等）跳过
                if event.get("event") in ("message", "agent_message"):
                    content = event.get("answer", "")
                    if content:
                        yield sse({"content": content})
                elif event.get("event") == "error":
                    yield sse({"error": f"Dify: {event.get('message', '未知错误')}"})
        except Exception as e:
            print(f"  ❌ [Dify] 错误: {e}")
            yield sse({"error": f"Dify 调用失败: {e}"})
        print(f"  ✅ [Dify] 完成\n")
        yield SSE_DONE

    return sse_response(generate())


# ── 通道③ LangChain ReAct Agent（工具调用 + 逐 token）──


@app.route("/agent/single", methods=["POST"])
def agent_single():
    from langchain_core.messages import HumanMessage, ToolMessage
    from agents.single_agent import stream

    data = request.get_json() or {}
    question = data.get("question", "帮我查 OBJ-0001 的状态和异常")
    object_id = data.get("object_id", "")
    if object_id and object_id not in question:
        question = f"帮我分析对象 {object_id}：{question}"

    print(f"\n{'='*60}")
    print(f"🤖 [ReAct Agent] 收到请求: {question[:80]}...")
    print(f"{'='*60}")

    def generate():
        if not os.getenv("DEEPSEEK_API_KEY"):
            yield sse({"error": "未配置 DEEPSEEK_API_KEY，请编辑 .env"})
            yield SSE_DONE
            return
        try:
            for chunk, _meta in stream(
                [HumanMessage(content=question)],
                stream_mode="messages",
            ):
                if isinstance(chunk, ToolMessage):
                    print(f"  🔧 [Tool] {chunk.name}: {str(chunk.content)[:100]}...")
                    yield sse({"tool": chunk.name, "content": f"\n🔧 [{chunk.name}] {chunk.content}\n\n"})
                else:
                    content = getattr(chunk, "content", "")
                    if content:
                        yield sse({"content": content})
        except Exception as e:
            print(f"  ❌ [ReAct Agent] 错误: {e}")
            yield sse({"error": f"LangChain Agent 调用失败: {e}"})
        print(f"  ✅ [ReAct Agent] 完成\n")
        yield SSE_DONE

    return sse_response(generate())


# ── 健康检查 ─────────────────────────────────────────


@app.route("/health")
def health():
    return jsonify({
        "status": "ok",
        "objects": len(OBJECTS),
        "deepseek_configured": bool(os.getenv("DEEPSEEK_API_KEY")),
        "dify_configured": any(a.get("api_key") for a in _load_dify_config().get("agents", [])),
    })


if __name__ == "__main__":
    print("""
╔════════════════════════════════════════════════╗
║   Day1 Agent 平台                              ║
║   http://localhost:8081                        ║
║                                                ║
║   通道① POST /gateway/chat       DeepSeek 直连 ║
║   通道② POST /gateway/dify/chat  Dify Agent    ║
║   通道③ POST /agent/single       LangChain     ║
║                                                ║
║   配置：.env（DeepSeek）+ dify_agents.json     ║
╚════════════════════════════════════════════════╝
""")
    # threaded=True：LangChain 工具会回调本服务的 /api/objects
    app.run(host="0.0.0.0", port=8081, debug=True, threaded=True)
